package com.mystore.pageobject;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class myAccount 
{

	WebDriver ldriver;
	
	public myAccount(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
		
	}
	@FindBy(id="email")
	WebElement createEmailId ;
	@FindBy(id="submit")
	WebElement submitCreate;
	
	@FindBy(id="username")
	WebElement UserName;
	
	@FindBy(id="passwd")
	WebElement Password;
	
	@FindBy(id="signin")
	WebElement Singin;
	  @FindBy(xpath="//*[@title='View my customer account']")
      WebElement userName;
	
	public void email(String emailadd)
	{
		createEmailId.sendKeys("emailadd");
	}

   public void submitBtn()
   {
	   submitCreate.click();
   }
   public void enterUserName(String username)
   {
	   UserName.sendKeys(username);
   }
   public void enterPassWord(String Pass)
   {
	   Password.sendKeys(Pass);
   }
   public void clickSignIn()
   {
	   Singin.click();
   }
   public String getUserName()
   {
	 String Text=  userName.getText();
	 return Text;
   }
   
   }