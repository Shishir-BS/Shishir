package com.mystore.testcases;

import org.testng.Assert;

import com.mystore.pageobject.AccountCreationPage;
import com.mystore.pageobject.indexpage;
import com.mystore.pageobject.myAccount;
import com.mystore.pageobject.myAccountPage;

public class Tc_myaccountpagetest extends BaseClass

{
public void verifyRegistrationAndLogin()
{
	
	indexpage pg= new indexpage(driver);
	pg.clickOnSignIn();
	
	myAccount myaccountpg= new myAccount(driver);
	myaccountpg.email("ritesh@123");
	myaccountpg.submitBtn();
	
	AccountCreationPage accountcreation=new AccountCreationPage(driver);
	
	accountcreation.selectTitleMrs();
	accountcreation.customerFirstname("Ritesh");
	accountcreation.enterCustomerLastName("singh");
	accountcreation.enterPassword("ritesh@123");
	accountcreation.enterAddressFirstName("Prachi");
	accountcreation.enterAddressLastName("Gupta");
	accountcreation.enterAddress("18/8 worli road");

	accountcreation.enterCity("Mumbai");
	accountcreation.selectState("Alabama");

	accountcreation.enterPostcode("00000");
	accountcreation.selectCountry("United States");
	accountcreation.enterMobilePhone("9891778192");
	accountcreation.enterAlias("Home");

	logger.info("entered user details on account creation page.");

	accountcreation.clickOnRegister();
	logger.info("clicked on Register button");
	accountcreation.enterAddressFirstName("Prachi");
	accountcreation.enterAddressLastName("Gupta");
	accountcreation.enterAddress("18/8 worli road");

	accountcreation.enterCity("Mumbai");
	accountcreation.selectState("Alabama");

	accountcreation.enterPostcode("00000");
	accountcreation.selectCountry("United States");
	accountcreation.enterMobilePhone("9891778192");
	accountcreation.enterAlias("Home");

	logger.info("entered user details on account creation page.");

	accountcreation.clickOnRegister();
	logger.info("clicked on Register button");.enterAddressFirstName("Prachi");
	accCreationPg.enterAddressLastName("Gupta");
	accCreationPg.enterAddress("18/8 worli road");

	accCreationPg.enterCity("Mumbai");
	accCreationPg.selectState("Alabama");

	accCreationPg.enterPostcode("00000");
	accCreationPg.selectCountry("United States");
	accCreationPg.enterMobilePhone("9891778192");
	accCreationPg.enterAlias("Home");

	logger.info("entered user details on account creation page.");

	accCreationPg.clickOnRegister();
	logger.info("clicked on Register button");.enterAddressFirstName("Prachi");
	accCreationPg.enterAddressLastName("Gupta");
	accCreationPg.enterAddress("18/8 worli road");

	accCreationPg.enterCity("Mumbai");
	accCreationPg.selectState("Alabama");

	accCreationPg.enterPostcode("00000");
	accCreationPg.selectCountry("United States");
	accCreationPg.enterMobilePhone("9891778192");
	accCreationPg.enterAlias("Home");

	

	accCreationPg.clickOnRegister();
	logger.info("clicked on Register button");
	
	myAccountPage mypg= new myAccountPage(driver);
	
	String UserName=mypg.getUserName();
	Assert.assertEquals("Ritesh", UserName);
}
	public void verifyLogin()
	{
		indexpage pg= new indexpage(driver);
		pg.clickOnSignIn();
		
		myAccount myaccountpg=new myAccount(driver);
		myaccountpg.email("ritesh");
		myaccountpg.enterPassWord("ritesh@123");
		myaccountpg.clickSignIn();
		myAccountPage mypg= new myAccountPage(driver);
		
		String UserName=mypg.getUserName();
		Assert.assertEquals("Ritesh", UserName);
	}
		
	}
	
	
}	

