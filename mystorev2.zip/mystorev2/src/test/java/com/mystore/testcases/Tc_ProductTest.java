package com.mystore.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mystore.pageobject.indexpage;
import com.mystore.pageobject.myAccount;
import com.mystore.pageobject.myAccountPage;



public class Tc_ProductTest extends BaseClass
{
	
	
	public void verifySearchProduct()
	{
     indexpage pg = new  indexpage(driver);
     pg.clickOnSignIn();
     
     myAccount myaccountpg=new myAccount(driver);
		myaccountpg.email("ritesh");
		myaccountpg.enterPassWord("ritesh@123");
		myaccountpg.clickSignIn();
		
		//Enter searchkey in search box
		myAccountPage mypg= new myAccountPage(driver); 
		myAccountPage mypg.EnterDataInSearchBox(searchKey);
		myAccountPage mypg.ClickOnSearchButton();
     
     
}
}